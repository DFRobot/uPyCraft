from microbit import uart

uart.init(baudrate=9600, bits=8, parity=None, stop=1, tx = pin0, rx = pin1)

uart.write("hello")

while True:
	msg = uart.read(5)
	if msg != None:
		break
print(msg)
uart.init(baudrate=115200)
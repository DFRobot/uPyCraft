#hardware platform: FireBeetle-ESP32

import MLX90614
from machine import Pin,I2C
import time

i2c = I2C(scl=Pin(22), sda=Pin(21), freq=100000)
ir=MLX90614.MLX90614(i2c)

while True:
    time.sleep(1)
    print("Object  %s *C"% ir.getObjCelsius())
    print("Object  %s *F"% ir.getObjFahrenheit())
    print("Ambient %s *C"% ir.getEnvCelsius())
    print("Ambient %s *F"% ir.getEnvFahrenheit())
    print()

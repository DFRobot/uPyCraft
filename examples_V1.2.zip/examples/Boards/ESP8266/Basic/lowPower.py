#hardware platform: FireBeetle-ESP8266

import machine
import time

rtc = machine.RTC()
rtc.irq(trigger=rtc.ALARM0, wake=machine.DEEPSLEEP)

if machine.reset_cause() == machine.DEEPSLEEP_RESET:
   print('woke from a deepsleep')
print("deepsleep 3 seconds")
rtc.alarm(rtc.ALARM0, 3000)
machine.deepsleep()

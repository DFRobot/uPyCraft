#hardware platform: FireBeetle-ESP8266

from machine import Timer,RTC

rtc=RTC()
tim0 = Timer(-1)
tim1 = Timer(-1)

tim0.init(period=3000, mode=Timer.ONE_SHOT, callback=lambda t:print("performing at the first 3 seconds once, timestamp:"+str(rtc.datetime())))
tim1.init(period=1000, mode=Timer.PERIODIC, callback=lambda t:print("performing period=1s, timestamp: "+str(rtc.datetime())))

try:
  while True:
    pass
except:
  tim0.deinit()
  tim1.deinit()
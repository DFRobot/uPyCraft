#hardware platform: FireBeetle-ESP8266

import ht1632

DATAPIN=5
CLKPIN =4
CSPIN  =13

led=ht1632.HT1632C(DATAPIN,CLKPIN,CSPIN,24,8)
led.text("DFR",0,0)
led.show()

while True:
  led.scroll(-1,0)
  led.show()
  time.sleep(0.5)
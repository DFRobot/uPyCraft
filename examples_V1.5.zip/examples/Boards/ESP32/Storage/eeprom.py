#hardware platform:FireBeetle-ESP32

from machine import Pin,I2C
import time

i2c = I2C(scl=Pin(22),sda=Pin(21), freq=10000)
b=bytearray("dfrobot")
i2c.writeto_mem(0x50,0,b,addrsize=16)
time.sleep(0.1)
print(i2c.readfrom_mem(0x50,0,7,addrsize=16))

#hardware platform: FireBeetle-ESP8266

import ht1632

DATAPIN=10
CLKPIN =13
CSPIN  =25

led=ht1632.HT1632C(DATAPIN,CLKPIN,CSPIN)
led.text("DFR",0,0)
led.show()

while True:
  led.scroll(-1,0)
  led.show()
  time.sleep(0.5)
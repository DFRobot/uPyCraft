#hardware platform: FireBeetle-ESP32
from machine import Pinimport time
value=1
counter=0
def func(v):
  global value,counter
  time.sleep_ms(50)  if(button.value() == 0):    return  while(button.value() == 1):    time.sleep_ms(100)  time.sleep_ms(100)  counter+=1  led.value(value)
  value = 0 if value else 1
  print("IRQ ",counter)

led = Pin(25, Pin.OUT)
led.value(0)
button = Pin(27, Pin.IN)
button.irq(trigger=Pin.IRQ_RISING, handler=func)
while True:
  pass
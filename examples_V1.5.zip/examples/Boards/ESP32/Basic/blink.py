#hardware platform: FireBeetle-ESP32
#The information below shows blink is unavailble for the current version.
# D0  D1  D5  D6   CLK  SD0  SD1  CMD
# IO1 IO3 IO9 IO10 IO6  IO7  IO8  IO11

import time
from machine import Pin
led=Pin(2,Pin.OUT)

while True:
  led.value(1)
  time.sleep(0.5)
  led.value(0)
  time.sleep(0.5)
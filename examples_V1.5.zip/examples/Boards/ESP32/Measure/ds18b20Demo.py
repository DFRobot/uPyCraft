#hardware platform: FireBeetle-ESP32

from machine import Pin
import onewire
import ds18x20
import time

ow = onewire.OneWire(Pin(25))
ds=ds18x20.DS18X20(ow)
while True:
  roms=ds.scan()
  ds.convert_temp()
  for rom in roms:
    print(ds.read_temp(rom))
  time.sleep(1)


#hardware platform: FireBeetle-ESP32

from machine import UART
import urm07
import time

u2 = UART(2,baudrate=19200,rx=25,tx=26,timeout=10)
time.sleep(1)

urm = urm07.URM07(u2,interval=200)
#urm.setDeviceAddr(0x11)
#urm.setBaudRate(urm07.BAUDRATE19200)
while True:
  distance = urm.getDistance()
  if(distance == 65535):
    print("measure distance failure!!!")
  else:
    print("distance=%d mm"%distance)
  print("temp=%3.1f C"%(urm.getTemperature()/10))
  
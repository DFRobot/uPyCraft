#hardware platform: pyboard V1.1

from pyb import Accel
import time

accel=Accel()

while True:
  time.sleep(0.1)
  print("x:%d, y:%d, z:%d"%(accel.x(),accel.y(),accel.z()))
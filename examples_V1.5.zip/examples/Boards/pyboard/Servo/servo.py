#hardware platform: pyboard V1.1

import pyb
import time

s1=pyb.Servo(1)
s2=pyb.Servo(2)

s1.angle(45)
s2.angle(0)
time.sleep(1.5)

s1.angle(-60,1500)
s2.angle(30,1500)

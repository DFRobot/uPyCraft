#hardware platform: FireBeetle-ESP8266

from machine import Pinimport time
button=Pin(15,Pin.IN) #D4led=Pin(13,Pin.OUT)   #D2
while True:  led.value(button.value())  time.sleep(0.1)
#hardware platform: FireBeetle-ESP8266

from machine import RTC
import time

rtc = RTC()
print(rtc.datetime())
#rtc.datetime((2017,5,20,5,0,0,0,0))
print(rtc.datetime())
time.sleep(3.5)
print(rtc.datetime())
print(rtc.memory())
rtc.memory("dfrobot"+str(rtc.datetime()[6]))


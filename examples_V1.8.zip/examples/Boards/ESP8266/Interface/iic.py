#hardware platform: FireBeetle-ESP8266
#Please refer to Examples=>Storage=>eeprom.py
#hardware platform: FireBeetle-ESP8266
#the current version does not support
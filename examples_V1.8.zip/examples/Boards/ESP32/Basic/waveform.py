#hardware platform: FireBeetle-ESP32
#GPIO25 ouput sine wave, GPIO26 output triangle wave

from machine import DAC,Pin
import math
import time

dac0=DAC(Pin(25))
dac1=DAC(Pin(26))
a=0
while True:
  value=math.sin(a*math.pi/180)         #get sine
  dac0.write(int(100+value*100))        #ouput wave
  dac1.write(a*255//360)
  a+=1
  if(a==361):
    a=0
  time.sleep(0.0001)

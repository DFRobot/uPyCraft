#hardware platform: FireBeetle-ESP32
#Please refer to Examples=>Storage=>eeprom.py
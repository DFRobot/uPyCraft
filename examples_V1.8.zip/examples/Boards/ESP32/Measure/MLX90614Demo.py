#hardware platform: FireBeetle-ESP32

import MLX90614
from machine import Pin,I2C
import time

i2c = I2C(scl=Pin(22), sda=Pin(21), freq=100000)    #create I2C object,init I2C
ir=MLX90614.MLX90614(i2c)                           #create ir object,and transmit the i2c object to it

while True:
  time.sleep(1)
  print("Object  %s *C"% ir.getObjCelsius())        #print celsius of Object
  print("Object  %s *F"% ir.getObjFahrenheit())     #print fahrenheit of Object
  print("Ambient %s *C"% ir.getEnvCelsius())        #print celsius of Ambient
  print("Ambient %s *F"% ir.getEnvFahrenheit())     #print fahrenheit of Ambient
  print()

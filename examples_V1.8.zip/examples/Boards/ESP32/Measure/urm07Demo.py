#hardware platform: FireBeetle-ESP32

from machine import UART
import urm07
import time

u2 = UART(2,baudrate=19200,rx=25,tx=26,timeout=10)  #create UART object,init id,baudrate,tx,rx,timeout
time.sleep(1)

urm = urm07.URM07(u2,interval=200)                  #create URM07 object,,and transmit the i2c object to it,set interval
#urm.setDeviceAddr(0x11)
#urm.setBaudRate(urm07.BAUDRATE19200)
while True:
  distance = urm.getDistance()                      #get the distance from urm
  if(distance == 65535):
    print("measure distance failure!!!")
  else:
    print("distance=%d mm"%distance)
  print("temp=%3.1f C"%(urm.getTemperature()/10))   #get the distance from urm,the integer is 3 bits,and the float is 1 bit
  
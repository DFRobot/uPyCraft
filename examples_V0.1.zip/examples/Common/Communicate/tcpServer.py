import network
import socket
import time

SSID="DFROBOT_AP"
PASSWORD="12345678"
port=10000
wlan=None

def connectWifi(ssid,passwd):
  global wlan
  wlan=network.WLAN(network.STA_IF)
  wlan.active(True)
  wlan.disconnect()
  wlan.connect(ssid,passwd)
  while(wlan.ifconfig()[0]=='0.0.0.0'):
    time.sleep(1)
  return True

connectWifi(SSID,PASSWORD)
ip=wlan.ifconfig()[0]
listenSocket = socket.socket()
listenSocket.bind((ip,port))
listenSocket.listen(1)
listenSocket.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
print ('tcp waiting...')
try:
  while True:
    print("accepting.....")
    conn,addr = listenSocket.accept()
    print(addr,"connected")

    while True:
      data = conn.recv(1024)
      if(len(data) == 0):
        print("close socket")
        conn.close()
        break
      print(data)
      ret = conn.send(data)
except:
    listenSocket.close()

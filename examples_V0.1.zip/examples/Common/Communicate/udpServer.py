import socket
import network
import time

port = 10000
SSID="DFROBOT_AP"
PASSWORD="12345678"

def connectWifi(ssid,passwd):
  wlan=network.WLAN(network.STA_IF)
  wlan.active(True)
  wlan.disconnect()
  wlan.connect(ssid,passwd)
  while(wlan.ifconfig()[0]=='0.0.0.0'):
    time.sleep(1)
  return True

if(connectWifi('DFROBOT_AP','12345678') == True):
  s=socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
  s.setsockopt(socket.SOL_SOCKET,socket.SO_REUSEADDR,1)  
  ip=wlan.ifconfig()[0]
  s.bind((ip,port))
  print('waiting...')
  while True:
    data,addr=s.recvfrom(1024)
    print('received:',data,'from',addr)
    s.sendto(data,addr)
from machine import ADC
from machine import time

adc0=ADC(0)

while True:
  print("adc0=",adc0.read())
  time.sleep(1)
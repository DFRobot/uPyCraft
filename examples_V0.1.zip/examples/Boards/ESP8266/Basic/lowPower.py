import machine
import time
print("wake up 5 seconds")
rtc = machine.RTC()
rtc.irq(trigger=rtc.ALARM0, wake=machine.DEEPSLEEP)
if machine.reset_cause() == machine.DEEPSLEEP_RESET:
   print('woke from a deepsleep')
print("deepsleep 10 seconds")
rtc.alarm(rtc.ALARM0, 5000)
machine.deepsleep()

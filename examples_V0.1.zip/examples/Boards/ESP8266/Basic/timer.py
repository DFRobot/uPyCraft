from machine import Timer

tim0 = Timer(-1)
tim1 = Timer(-1)

tim0.init(period=3000, mode=Timer.ONE_SHOT, callback=lambda t:print("one shot 3s"))
tim1.init(period=1000, mode=Timer.PERIODIC, callback=lambda t:print("period 1s"))
try:
  while True:
    pass
except:
  tim0.deinit()
  tim1.deinit()
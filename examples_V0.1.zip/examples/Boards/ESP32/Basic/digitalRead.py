#FireBeetle-32

from machine import Pin
import time

button=Pin(27,Pin.IN)
led=Pin(2,Pin.OUT)

while True:
  led.value(button.value())
  time.sleep(0.1)

#Pin(25)������Ҳ� Pin(26)������ǲ�
from machine import DAC,Pin
import math
import time

dac0=DAC(Pin(25))
dac1=DAC(Pin(26))
a=0
while True:
  value=math.sin(a*math.pi/180)
  dac0.write(int(100+value*100))
  dac1.write(a*255//360)
  a+=1
  if(a==361):
    a=0
  time.sleep(0.0001)

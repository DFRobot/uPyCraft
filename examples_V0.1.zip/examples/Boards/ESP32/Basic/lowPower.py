from machine import Pin
value=1
counter=0
def func(v):
  global value,counter
  counter+=1
  led.value(value)
  if(value == 0):
    value = 1
  else:
    value = 0
  print("IRQ ",counter)

led = Pin(13, Pin.OUT)
led.value(0)
button = Pin(0, Pin.IN)
button.irq(trigger=Pin.IRQ_FALLING, handler=func)
while True:
  pass
#hardware platform: FireBeetle-ESP8266

from machine import ADC
import time

adc0=ADC(0)

while True:
  print("adc0=",adc0.read())
  time.sleep(0.1)
#hardware platform:FireBeetle-ESP8266import timefrom machine import Pin,I2C
i2c = I2C(scl=Pin(5),sda=Pin(4), freq=100000)b=bytearray("dfrobot")i2c.writeto_mem(0x50,0,b,addrsize=16)
time.sleep(0.1)
print(i2c.readfrom_mem(0x50,0,7,addrsize=16))
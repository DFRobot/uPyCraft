#hardware platform:FireBeetle-ESP8266from machine import SPI,Pinimport sdcardimport osspi = SPI(baudrate=100000, polarity=1, phase=0, sck=Pin(14), mosi=Pin(13), miso=Pin(12))sd = sdcard.SDCard(spi, Pin(2))os.mount(sd,"/sd")print(os.listdir('/sd'))
fd=open('/sd/dfrobot.txt','rw')
fd.write('hello dfrobot')
fd.seek(0)
print(fd.read())
fd.close()
os.umount("/sd")
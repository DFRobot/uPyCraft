from umqtt.simple import MQTTClient
from machine import Pin
import network
import time

SSID="yourSSID"
PASSWORD="yourPASSWD"

led=Pin(2, Pin.OUT, value=0)

SERVER = "182.254.130.180"
CLIENT_ID = "yourClientID"
TOPIC = b"yourTOPIC"
username='yourIotUserName'
password='yourIotPassword'
state = 0
def sub_cb(topic, msg):
    global state
    print((topic, msg))
    if msg == b"on":
            led.value(1)
            state = 0
            print("1")
    elif msg == b"off":
            led.value(0)
            state = 1
            print("0")
    elif msg == b"toggle":
            # LED is inversed, so setting it to current state
            # value will make it toggle
            led.value(state)
            state = 1 - state
def connectWifi(ssid,passwd):
  global wlan
  wlan=network.WLAN(network.STA_IF)
  wlan.active(True)
  wlan.disconnect()
  wlan.connect(ssid,passwd)
  while(wlan.ifconfig()[0]=='0.0.0.0'):
    time.sleep(1)

connectWifi(SSID,PASSWORD)
server=SERVER
c = MQTTClient(CLIENT_ID, server,0,username,password)
c.set_callback(sub_cb)
c.connect()
c.subscribe(TOPIC)
print("Connected to %s, subscribed to %s topic" % (server, TOPIC))
try:
  while 1:
    c.wait_msg()
finally:
  c.disconnect()
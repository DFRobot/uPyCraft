#hardware platform: pyboard V1.1
from pyb import Switch
from pyb import LED

def mycallback():
  led.toggle()

led=LED(1)
led.off()
userButton=Switch()

#userButton.callback(lambda:led.toggle())
userButton.callback(mycallback)

while True:
  pass
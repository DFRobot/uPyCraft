#hardware platform: pyboard V1.1

from pyb import Timer
from time import sleep
import pyb
tim=pyb.Timer(5,freq=100)
tchannel=tim.channel(1,Timer.PWM,pin=pyb.Pin.board.X1,pulse_width=0)
max_width=50000
min_width=100
wstep=1500
cur_width=min_width
while True:
  tchannel.pulse_width(cur_width)
  sleep(0.1)
  cur_width+=wstep
  if cur_width>max_width:
    cur_width=max_width
    wstep *=-1
  elif cur_width<min_width:
    cur_width=min_width
    wstep*=-1
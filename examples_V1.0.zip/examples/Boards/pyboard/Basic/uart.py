#hardware platform: pyboard V1.1
#uart1:tx->x9,rx->x10
from pyb import UART

uart=UART(1,9600)
uart.write("hello")
msg=""
while True:
  msg=uart.read(5)
  if msg!=None:
    break
print(msg)
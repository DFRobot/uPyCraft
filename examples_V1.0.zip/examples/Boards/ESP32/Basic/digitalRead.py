#hardware platform: FireBeetle-ESP32

from machine import Pin
import time

button=Pin(27,Pin.IN) #D4
led=Pin(25,Pin.OUT)   #D2

while True:
  led.value(button.value())
  time.sleep(0.1)

#hardware platform: FireBeetle-ESP8266

from machine import UART

uart=UART(0)
uart.write("dfrobot\r\n")